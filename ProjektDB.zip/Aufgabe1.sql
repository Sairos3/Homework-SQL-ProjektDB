-- 1. Datenbank ProjektDB erstellen
CREATE DATABASE ProjektDB;
GO